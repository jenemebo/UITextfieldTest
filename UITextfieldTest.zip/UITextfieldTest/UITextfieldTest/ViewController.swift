//
//  ViewController.swift
//  UITextfieldTest
//
//  Created by Chunhua on 2017/10/7.
//  Copyright © 2017年 HAS Tech. All rights reserved.
//


import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    let big5Encoding = CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.Big5.rawValue))

    
    
    @IBOutlet weak var inputTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        inputTextField.delegate = self;

    }

    
    func textFieldDidEndEditing(textField: UITextField) {
        
        let checkLetters :NSMutableCharacterSet = NSMutableCharacterSet.init()
        checkLetters.addCharactersInString("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
        
        let myString2 = inputTextField.text! as NSString
        NSLog("myString2 \(myString2)")

        // 可以判斷目前鍵盤是什麼輸入法
        let lang: NSString = textField.textInputMode!.primaryLanguage!
        
        let strBytes : NSInteger =  (inputTextField.text?.lengthOfBytesUsingEncoding(NSUTF8StringEncoding))!;
       
        NSLog("bytes \(strBytes)")
        
        NSLog("containsOnlyLetters \(containsOnlyLetters(textField.text!))")
        
        NSLog("length \((inputTextField.text! as NSString).length)")
        
       let strLength = inputTextField.text?.characters.count
    
        let myString = inputTextField.text
        let immutableData = NSData(bytes: (myString)!, length: 6)
         NSLog("immutableData length\(immutableData)")
       
        
        let newStr = NSString(data: immutableData, encoding: NSUTF8StringEncoding)
        NSLog("newStr is \(newStr!)")
  
        // 全英文 限制位元數只能為6
        if(strLength == strBytes && strBytes > 6 && myString2.rangeOfCharacterFromSet(checkLetters).location != NSNotFound){
            
            inputTextField.text = (inputTextField.text! as NSString).substringToIndex(6) ?? ""
        }
        // 中文
        else if (strLength != strBytes && strBytes > 6 && myString2.rangeOfCharacterFromSet(checkLetters).location == NSNotFound ){
            
            inputTextField.text  = (inputTextField.text! as NSString).substringToIndex(3) ?? ""
        }
        // 中英文夾雜
        else if (strLength != strBytes && strBytes > 6 && myString2.rangeOfCharacterFromSet(checkLetters).location != NSNotFound ){
            
            inputTextField.text  = (inputTextField.text! as NSString).substringToIndex(4) ?? ""
        }
        
    }
    
    
    // 判斷是否只有英文字母
    func containsOnlyLetters(input: String) -> Bool {
        for chr in input.characters {
            if (!(chr >= "a" && chr <= "z") && !(chr >= "A" && chr <= "Z") ) {
                return false
            }
        }
        return true
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        // 結束編輯 把鍵盤隱藏起來
        self.view.endEditing(true)
        
        return true
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}



extension NSData {
    
    
    var big5String: String? {
        let big5 = CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.Big5.rawValue))
        
        return NSString(data: self, encoding: big5) as? String;
        
    }
}

extension String {
    
    var big5Data: NSData? {
        let big5 = CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.Big5.rawValue))
        return self.dataUsingEncoding(big5, allowLossyConversion: false);
    }
    
}

